package com.tarena.day0205;

import android.app.Activity;
import android.os.Bundle;

public class Day02_05_FrameLayoutActivity extends Activity {
    /** Called when the activity is first created. */
    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.main);
    }
}